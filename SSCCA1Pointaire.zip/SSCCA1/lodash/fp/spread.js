var convert = require('./convert'),
    func = convert('spread', require('../spread'));

func.placeholder = require('./placeholder');
module.exports = func;
