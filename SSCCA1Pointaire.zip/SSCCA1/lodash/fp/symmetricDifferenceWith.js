module.exports = require('./xorWith');
