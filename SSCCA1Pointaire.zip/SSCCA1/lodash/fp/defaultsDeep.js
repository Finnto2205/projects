var convert = require('./convert'),
    func = convert('defaultsDeep', require('../defaultsDeep'));

func.placeholder = require('./placeholder');
module.exports = func;
