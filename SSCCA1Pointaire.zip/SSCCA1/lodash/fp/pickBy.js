var convert = require('./convert'),
    func = convert('pickBy', require('../pickBy'));

func.placeholder = require('./placeholder');
module.exports = func;
