var convert = require('./convert'),
    func = convert('replace', require('../replace'));

func.placeholder = require('./placeholder');
module.exports = func;
