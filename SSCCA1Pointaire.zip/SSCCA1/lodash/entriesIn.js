module.exports = require('./toPairsIn');
