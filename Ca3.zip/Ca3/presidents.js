let leaders = [
    { name: "Biden", country: "America", path: "biden.png" },
    { name: "Draghi", country: "Italy", path: "Draghi.png" },
    { name: "Jinping", country: "China", path: "jinping.png" },
    { name: "Johnson", country: "England", path: "johnson.png" },
    { name: "Macron", country: "France", path: "Macron.png" },
    { name: "Merkel", country: "Germany", path: "merkel.png" },
    { name: "Morrison", country: "Australia", path: "morrison.png" },
    { name: "Suga", country: "Japan", path: "suga.png" },
    { name: "Trudeau", country: "Canada", path: "Trudeau.png" },
    { name: "Vonderleyen", country: "Europe", path: "vonderleyen.png" }
];

let deletedLeaders = [];

function add() {
    if (leaders.length > 0) {
        const imageBox = document.getElementById("imageBox");
        const list = document.getElementById("list");

        const leader = leaders.pop();

        if (leader) {
            
            const listItem = document.createElement("li");
            listItem.textContent = `${leader.name} - ${leader.country}`;
            list.appendChild(listItem);

            const img = document.createElement("img");
            img.src = leader.path;
            img.alt = leader.name;

            img.addEventListener("mouseover", function () {
                const nameDiv = document.getElementById("name");
                nameDiv.textContent = leader.name;
            });

            img.addEventListener("mouseout", function () {
                const nameDiv = document.getElementById("name");
                nameDiv.textContent = "";
            });

           
            imageBox.appendChild(img);

            
            deletedLeaders.push(leader);
        }
    }
}

function remove() {
    if (leaders.length > 0) {
        const removedLeader = leaders.shift();
        deletedLeaders.push(removedLeader);

        const list = document.getElementById("list");
        const firstItem = list.firstChild;
        if (firstItem) {
            list.removeChild(firstItem);
        }

        const imageBox = document.getElementById("imageBox");
        const firstImage = imageBox.firstChild;
        if (firstImage) {
            imageBox.removeChild(firstImage);
        }
    }
}

function swap() {
    if (leaders.length >= 2) {
        const temp = leaders[0];
        leaders[0] = leaders[leaders.length - 1];
        leaders[leaders.length - 1] = temp;

        const list = document.getElementById("list");
        const items = list.getElementsByTagName("li");
        if (items.length >= 2) {
            const firstItem = items[0];
            const lastItem = items[items.length - 1];

            list.replaceChild(lastItem, firstItem);
            list.appendChild(firstItem);
        }

        const imageBox = document.getElementById("imageBox");
        const images = imageBox.getElementsByTagName("img");
        if (images.length >= 2) {
            const firstImage = images[0];
            const lastImage = images[images.length - 1];

            imageBox.replaceChild(lastImage, firstImage);
            imageBox.appendChild(firstImage);
        }
    }
}
function shuffle() {
    for (let i = leaders.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [leaders[i], leaders[j]] = [leaders[j], leaders[i]];
    }

    const list = document.getElementById("list");
    while (list.firstChild) {
        list.removeChild(list.firstChild);
    }

    leaders.forEach((leader) => {
        const listItem = document.createElement("li");
        listItem.textContent = `${leader.name} - ${leader.country}`;
        list.appendChild(listItem);
    });

    const imageBox = document.getElementById("imageBox");
    while (imageBox.firstChild) {
        imageBox.removeChild(imageBox.firstChild);
    }

    leaders.forEach((leader) => {
        const img = document.createElement("img");
        img.src = leader.path;
        img.alt = leader.name;

        img.addEventListener("mouseover", function () {
            const nameDiv = document.getElementById("name");
            nameDiv.textContent = leader.name;
        });

        img.addEventListener("mouseout", function () {
            const nameDiv = document.getElementById("name");
            nameDiv.textContent = "";
        });

        imageBox.appendChild(img);
    });
}