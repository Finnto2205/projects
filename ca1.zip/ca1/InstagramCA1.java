import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.geometry.*;
import javafx.scene.image.*;
import javafx.scene.image.*;
import javafx.scene.control.*;
import javafx.scene.text.*;
import javafx.scene.paint.Color;
import javax.swing.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.geometry.Pos.*;
import javafx.event.*;
import javafx.scene.control.PasswordField;
import javafx.util.*;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
//Declare SQL imports
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Optional;



public class InstagramCA1 extends Application
{

   private Scene scene;
   private BorderPane sceneLayout;
   private ImageView instaImageView;
  // private TextArea taAddress;
   private Button btDone;
   private Label insta, account;
   private Image instaImage;
   private Button LogIn, SignUp;
   private TextField userName;
   private PasswordField password;
   private TextArea taDetails;
   
   //Sql variables
   private final String LOCALHOST = "jdbc:mysql://localhost/instagram";
   private final String USER_NAME = "root";
   private final String PASSWORD = "password";

    private Connection conn = null;
   
   @Override
   public void start(Stage primaryStage)
  {
      
      
      sceneLayout=new BorderPane();
      sceneLayout.setTop(insta = new Label());
      insta.setFont(Font.font("Script MT Bold",FontWeight.BOLD,40));
      insta.setText("Instagram");
      insta.setMaxWidth(Double.MAX_VALUE);
      
      HBox hBox = new HBox(5);
      hBox.setAlignment(Pos.CENTER);
      hBox.getChildren().addAll(instaImageView = new ImageView(instaImage = new Image("instagram.jpg")));
      
      sceneLayout.setBottom(hBox);
     // sceneLayout.setCenter(instaImageView = new ImageView(instaImage = new Image("instagram.jpg")));
      
      insta.setAlignment(Pos.CENTER);
      
      sceneLayout.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY,Insets.EMPTY)));
      userName = new TextField();
      PasswordField password = new PasswordField();
      VBox vBox = new VBox();
      vBox.setAlignment(Pos.CENTER);
      vBox.getChildren().add(userName);
      vBox.getChildren().add(password);
      vBox.getChildren().add(LogIn = new Button("Log In"));
      LogIn.setOnAction(e -> signUpAction());
      vBox.setPadding(new Insets(30,10,30,10));
      vBox.setSpacing(5);
      userName.setMaxWidth(Double.MAX_VALUE);
      password.setMaxWidth(Double.MAX_VALUE);
      LogIn.setMaxWidth(Double.MAX_VALUE);
      userName.setPromptText("Enter your user name");
      password.setPromptText("Enter Password");
      
      
      HBox subPane = new HBox();
      account = new Label();
      account.setPadding(new Insets(10,20,10,20));
      account.setText("Don't have an account? ");
      SignUp = new Button("Sign Up");
      account.setAlignment(Pos.CENTER_LEFT);                                            
      SignUp.setAlignment(Pos.CENTER_RIGHT); 
      //account.setTextFill(Color.LIGHTGRAY);
      subPane.getChildren().add(account);
      subPane.getChildren().add(SignUp);
      SignUp.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY,Insets.EMPTY)));

      subPane.setBorder(new Border(new BorderStroke(Color.LIGHTGRAY,
                                                  BorderStrokeStyle.SOLID,
                                                  new CornerRadii(1),
                                                  new BorderWidths(1))));
                              
      subPane.setAlignment(Pos.CENTER);
      SignUp.setTextFill(Color.LIGHTBLUE);
      vBox.getChildren().add(subPane);
     
      
     // sceneLayout.setCenter();
  
      LogIn.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, CornerRadii.EMPTY,Insets.EMPTY)));
      LogIn.setTextFill(Color.WHITE);
      sceneLayout.setCenter(vBox);
      
      scene = new Scene(sceneLayout);
      primaryStage.setScene(scene);
      primaryStage.setTitle("Instagram GUI");
      primaryStage.show();
  } 
  private void signUpAction() {//open
       String email = userName.getText().trim();
       String passkey = password.getText();
   
       if (email.isEmpty() || passkey.isEmpty()) {//open if
           // Create an alert dialog
           Alert alert = new Alert(AlertType.WARNING);
           alert.setTitle("Input Needed");
           alert.setHeaderText(null);
           alert.setContentText("Please enter email and password.");
   
           // Display the alert and wait for user response (modal)
           alert.showAndWait();
           return;
       }//close if
   
       // If both email and password are provided, proceed with signup logic
       insertIntoDatabase(email, "", passkey);
   }//close
   
    private boolean isValidEmail(String email) {//open
        return email.contains("@") && email.contains(".");
    }//close
    
       // Method to insert or update user in the database
       private void insertIntoDatabase(String email, String username, String passkey) {//open
           try {//open try
               // Establish a connection to the database
               conn = DriverManager.getConnection(LOCALHOST, USER_NAME, PASSWORD);
   
               // Define the SQL query for insertion or update
               String insertOrUpdateQuery = "INSERT INTO user (email, username, password) " +
                                            "VALUES (?, ?, ?) " +
                                            "ON DUPLICATE KEY UPDATE username = ?, password = ?";
   
               // Prepare the SQL statement
               PreparedStatement preparedStatement = conn.prepareStatement(insertOrUpdateQuery);
               preparedStatement.setString(1, email);
               preparedStatement.setString(2, username);
               preparedStatement.setString(3, passkey);
               preparedStatement.setString(4, username);
               preparedStatement.setString(5, passkey);
   
               // Execute the SQL statement
               preparedStatement.executeUpdate();
   
               // Display success message
               taDetails.appendText("User inserted or updated successfully.\n");
           }//close try 
           catch (SQLException e) {//open catch
               // Display error message if an SQL exception occurs
               taDetails.appendText("Error: " + e.getMessage() + "\n");
           }//close catch 
           finally {//open finally
               try {//open try
                   if (conn != null) {//open if
                       // Close the database connection
                       conn.close();
                       taDetails.appendText("Database connection closed.\n");
                   }//close if
               } //close try
               catch (SQLException ex) {//open catch
                   // Display error message if closing connection fails
                   taDetails.appendText("Error while closing connection: " + ex.getMessage() + "\n");
               }//close catch
           }//close try
       }//close
       
       // Method to show an alert dialog with specified type, title, and content
    private void showAlert(Alert.AlertType alertType, String title, String content) {//open
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }//close
      
       // Main method to launch the JavaFX application
       public static void main(String[] args) {//open
           launch(args);
       }//close
 }//close